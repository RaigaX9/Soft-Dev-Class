package edu.gatech.seclass.gradescalc;

import java.util.ArrayList;

public class Student {
	private String name;
	private String gtId;
	private String email;
	private int attendance;
	private GradesDB db;
	private ArrayList<Integer> assignmentGrades;
	private String team;
	
	
	public Student(String name, String gtId, String email, GradesDB db) {
		this.name = name;
		this.gtId = gtId;
		this.email = email;
		this.db = db;

	}
	
	public Student(String name, String gtId, String email, int attendance) {
		this.name = name;
		this.gtId = gtId;
		this.email = email;
		this.attendance = attendance;

	}
	
	public Student(String name, String gtId, GradesDB db) {
		this.name = name;
		this.gtId = gtId;
		this.db = db;

	}


	public String getName() {
		return this.name;
	}
	
	public String getGtid() {
		return this.gtId;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public int getAttendance() {
		return this.attendance;
	}

	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setGtid(String gtId) {
		this.gtId = gtId;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setAttendance(int attendance) {
		this.attendance = attendance;
	}
	
	public GradesDB getGDB(){
		return db;
	}
	
	public void setGDB(GradesDB db){
		this.db = db;
	}
	
	public int getAverageAssignmentsGrade() {
		//assignmentAvg = db.getAverageAssignmentsGrade(this);
		return db.getAverageAssignmentsGrade(this);
	}
	
	
	public int getAverageProjectsGrade() {
		return db.getAverageProjectsGrade(this);
	}
	

	public int getOverallGrade() {
		return db.getOverallGrade(this);
	}
	
	
	public String getTeam() {
		return this.team;
	}
	
	public void setTeam(String team) {
		this.team = team;
	}
	
	public ArrayList<Integer> getAssignmentGrades() {
		return this.assignmentGrades;
	}
	
	public void setAssignmentGrades(ArrayList<Integer> assignmentGrades){
		this.assignmentGrades = assignmentGrades;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((gtId == null) ? 0 : gtId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (gtId == null) {
			if (other.gtId != null)
				return false;
		} else if (!gtId.equals(other.gtId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	
}
