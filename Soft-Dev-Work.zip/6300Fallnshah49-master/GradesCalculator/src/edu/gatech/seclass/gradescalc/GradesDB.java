package edu.gatech.seclass.gradescalc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GradesDB {

	private String url;
	File f = null;
	FileInputStream fis = null;
	XSSFWorkbook wb = null;
	XSSFSheet spreadsheet = null;
	//XSSFRow row;
	HashSet<Student> totalStudents = new HashSet<Student>();
	private String formula = "AT * 0.2 + AS * 0.4 + PR * 0.4"; 
	
	public void loadSpreadsheet(String gdb){
		try{
			url = gdb;
			f = new File(url);
			fis = new FileInputStream(f);
			wb = new XSSFWorkbook(fis);

		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}

	public int getNumStudents() {

		XSSFSheet sheet = wb.getSheet("StudentsInfo");
		int numStudent = sheet.getLastRowNum();

		return numStudent;
	}

	public int getNumAssignments() {
		
		XSSFSheet sheet = wb.getSheet("IndividualGrades");
		int numAssignments = sheet.getRow(0).getLastCellNum() - 1;
		
		return numAssignments;
	}

	public int getNumProjects() {

		XSSFSheet sheet = wb.getSheet("IndividualContribs");
		int numProjects = sheet.getRow(0).getLastCellNum() - 1;
		
		return numProjects;
	}

	public HashSet<Student> getStudents() {
		HashSet<Student> studentSet = new HashSet<Student>();
		DataFormatter fmt = new DataFormatter();
		XSSFSheet sheet = wb.getSheet("StudentsInfo");

		for (int rn = sheet.getFirstRowNum() + 1; rn<=sheet.getLastRowNum(); rn++) {
			Row row = sheet.getRow(rn);
			if (row == null) {

			} 
			else {
				ArrayList<String> attrList = new ArrayList<String>();
				for (int cn = 0; cn < row.getLastCellNum(); cn++) {
					Cell cell = row.getCell(cn);
					if (cell == null) {
						attrList.add("null");
					} 
					else {
						String cellStr = fmt.formatCellValue(cell);
						attrList.add(cellStr);
					}
				}
				String name = attrList.get(0);
				String id = attrList.get(1);
				String email = attrList.get(2);
				
				Student student = new Student(name, id, email, this);
				
				studentSet.add(student);
			}
		}

		return studentSet;
	}

	public Student getStudentByName(String in_name) {
		Student returnedStudent = null;
		DataFormatter fmt = new DataFormatter();
		XSSFSheet sheet = wb.getSheet("StudentsInfo");

		for (int rn=sheet.getFirstRowNum() + 1; rn<=sheet.getLastRowNum(); rn++) {
			Row row = sheet.getRow(rn);
			if (row == null) {

			} 
			else {
				ArrayList<String> attrList = new ArrayList<String>();
				for (int cn = 0; cn < row.getLastCellNum(); cn++) {
					Cell cell = row.getCell(cn);
					if (cell == null) {
						attrList.add("null");
					} 
					else {
						String cellStr = fmt.formatCellValue(cell);
						attrList.add(cellStr);
					}
				}

				String name = attrList.get(0);
				String id = attrList.get(1);
				String email = attrList.get(2);
				
				if (name.compareTo(in_name) == 0) {
					returnedStudent = new Student(name, id, email, this);
					int attendance = getStudentAttendance(name);

					returnedStudent.setAttendance(attendance);

				}
			}
		}
		return returnedStudent;
	}

	public Student getStudentByID(String in_id) {
		Student returnedStudent = null;
		DataFormatter fmt = new DataFormatter();
		XSSFSheet sheet = wb.getSheet("StudentsInfo"); 

		for (int rn = sheet.getFirstRowNum() + 1; rn <= sheet.getLastRowNum(); rn++) {
			Row row = sheet.getRow(rn);
			if (row == null) {

			} 
			else {
				ArrayList<String> attrList = new ArrayList<String>();
				for (int cn = 0; cn < row.getLastCellNum(); cn++) {
					Cell cell = row.getCell(cn);
					if (cell == null) {
						attrList.add("null");
					} 
					else {
						String cellStr = fmt.formatCellValue(cell);
						attrList.add(cellStr);
					}
				}

				String name = attrList.get(0);
				String id = attrList.get(1);
				String email = attrList.get(2);

				if (id.compareTo(in_id) == 0) {
					returnedStudent = new Student(name, id, email, this);
					int attendance = getStudentAttendance(name);
					returnedStudent.setAttendance(attendance);
				}

			}
		}
		return returnedStudent;
	}

	public int getStudentAttendance(String in_name) {
		int attendance = 0;
		DataFormatter fmt = new DataFormatter();
		XSSFSheet sheet = wb.getSheet("Attendance");

		for (int rn = sheet.getFirstRowNum() + 1; rn <= sheet.getLastRowNum(); rn++) {
			Row row = sheet.getRow(rn);
			if (row == null) {

			} 
			else {
				ArrayList<String> attrList = new ArrayList<String>();
				for (int cn = 0; cn < row.getLastCellNum(); cn++) {
					Cell cell = row.getCell(cn);
					if (cell == null) {
						attrList.add("null");
					} 
					else {
						String cellStr;
						if (cn == 1)
							cellStr = String.valueOf(cell.getNumericCellValue());
						else
							cellStr = fmt.formatCellValue(cell);
						attrList.add(cellStr);
					}
				}

				String name = attrList.get(0);
				if (name.compareTo(in_name) == 0) {
					String attendance_str = attrList.get(1);
					attendance_str = attendance_str.trim().substring(0,attendance_str.trim().length());
					double fl_attendance = Float.parseFloat(attendance_str);
					attendance = (int)Math.round(fl_attendance);
				}
			}
		}
		return attendance;	
	}
	
	public void addAssignment(String add_assignment) {
		//ArrayList <String> assignments = new ArrayList <String>();
		XSSFSheet sheet = wb.getSheet("IndividualGrades");
		XSSFFont theFont = wb.createFont();
		XSSFCellStyle theStyle = wb.createCellStyle();

		theFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		theStyle.setFont(theFont);
		Row row = sheet.getRow(0);
		int lastCellNum = row.getLastCellNum();
		Cell theCell = row.createCell(lastCellNum);
		theCell.setCellValue(add_assignment);
		theCell.setCellStyle(theStyle);

		sheet.autoSizeColumn(lastCellNum);
		FileOutputStream out;
		try{
			out = new FileOutputStream(f);
			wb.write(out);
			out.close();
		} catch(FileNotFoundException e){
			e.printStackTrace();
		} catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void addGradesForAssignment(String assignmentName, HashMap<Student, Integer> grades) {
		
		XSSFSheet wsIndividualGrades = wb.getSheet("IndividualGrades");
		FileOutputStream out;

		try
		{
			int cellNumber = 0;
			Set<Student> studentKeys = grades.keySet();
			Iterator<Student> it =studentKeys.iterator();
			while(it.hasNext()){
				Student student = it.next();
				int valueGrade = grades.get(student);

				for (Row row : wsIndividualGrades) {
					for (Cell cell : row) {
						if(cell.getCellType() == Cell.CELL_TYPE_STRING && 
								cell.getStringCellValue().trim().equalsIgnoreCase(assignmentName)){

							cellNumber = cell.getColumnIndex();
						}
						else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
							if (cell.getStringCellValue().trim().equalsIgnoreCase(student.getName())) {
								cell = row.createCell(cellNumber);
								cell.setCellValue(valueGrade);

								break;
							}
						}
					}
				}
			}

			out = new FileOutputStream(f);
			wb.write(out);
			out.close();
		} 	

		catch (Exception e) {
			e.printStackTrace();
		}      
	}
	public int getAverageAssignmentsGrade(Student student1) {
		// TODO Auto-generated method stub
		double average=0.0, sum=0.0;
		XSSFSheet wsIndividualGrades = wb.getSheet("IndividualGrades");
		try
		{
			int counter=0;
			Row rowNum = wsIndividualGrades.getRow(0);
			int totalCells = rowNum.getLastCellNum();
			for (Row row : wsIndividualGrades) {
				for (Cell cell : row) {
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						if (cell.getStringCellValue().trim().equalsIgnoreCase(student1.getName())) {
							for(int i=1;i<totalCells;i++){
								Cell cell2 = row.getCell(i);
								if(cell2!=null){
									cell2.setCellType(Cell.CELL_TYPE_STRING);
									if(!cell2.getStringCellValue().trim().equals("")){
										sum = sum +Double.parseDouble(cell2.getStringCellValue());
										counter++;
									}
								}
							}
						}
					}
				}
			}
			average = sum/counter;

		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return (int)Math.round(average);
	}
	public int getAverageProjectsGrade(Student student) {
		double average=0, sum=0;		
		XSSFSheet IndividualContribsSheet = wb.getSheet("IndividualContribs");
		XSSFSheet TeamsSheet = wb.getSheet("Teams");
		XSSFSheet TeamGradesSheet = wb.getSheet("TeamGrades");

		try
		{
			
			Row rowNum = IndividualContribsSheet.getRow(0);
			int totalCells = rowNum.getLastCellNum();
			int counter=0;
			double[] arrayProjectGrades = new double[totalCells-1];
			double[] arrayTeamGrades = new double[totalCells-1];
			for (Row row : IndividualContribsSheet) {
				for (Cell cell : row) {
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						if (cell.getStringCellValue().trim().equalsIgnoreCase(student.getName())) {
							for(int i=1;i<totalCells;i++){
								Cell cell2 = row.getCell(i);							
								if(null !=cell2 ){
									cell2.setCellType(Cell.CELL_TYPE_STRING);
									if(!cell2.getStringCellValue().trim().equals("")){									
										arrayProjectGrades[i-1] = Double.parseDouble(cell2.getStringCellValue());
										counter++;
									}
								}
							}
							break;
						}
					}
				}
			}
			
			rowNum = TeamsSheet.getRow(0);
			String teamName ="";
			for (Row row : TeamsSheet) {
				for (Cell cell : row) {
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						if (cell.getStringCellValue().trim().equalsIgnoreCase(student.getName())) {
							teamName  = row.getCell(0).getStringCellValue().trim();
							break;
						}
					}
				}
			}

			 rowNum = TeamGradesSheet.getRow(0);
			 totalCells = rowNum.getLastCellNum();	
			for (Row row : TeamGradesSheet) {
				for (Cell cell : row) {
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						if (cell.getStringCellValue().trim().equalsIgnoreCase(teamName)) {
							for(int i=1;i<totalCells;i++){
								Cell cell2 = row.getCell(i);
								cell2.setCellType(Cell.CELL_TYPE_STRING);
								arrayTeamGrades[i-1] = Double.parseDouble(cell2.getStringCellValue());

							}
							break;
						}
					}
				}
			}
			
			for(int i=0;i<counter;i++){
				sum=sum+((arrayProjectGrades[i]*arrayTeamGrades[i])/100);
			}
			
			average=sum/counter;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return (int) Math.round(average);
	}
	public void addIndividualContributions(String projectName1, HashMap<Student, Integer> contributions1) {
		XSSFSheet individualContribsSheet = wb.getSheet("IndividualContribs");
		FileOutputStream out;
		try
		{
			int cellNumber = 0;
			Set<Student> studentKeys = contributions1.keySet();
			Iterator<Student> it =studentKeys.iterator();
			while(it.hasNext()){
				Student student = it.next();
				int valueGrade = contributions1.get(student);
				for (Row row : individualContribsSheet) {
					for (Cell cell : row) {
						if(cell.getCellType() == Cell.CELL_TYPE_STRING && cell.getStringCellValue().trim().equalsIgnoreCase(projectName1)){
							cellNumber=cell.getColumnIndex();
						}
						else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
							if (cell.getStringCellValue().trim().equalsIgnoreCase(student.getName())) {
								cell = row.createCell(cellNumber);
	            				cell.setCellValue(valueGrade);
	            				break;
							}
						}
					}
				}
			}
			out = new FileOutputStream(f);
			wb.write(out);
			out.close();
            wb = new XSSFWorkbook(new FileInputStream(f));
            individualContribsSheet = wb.getSheet("IndividualContribs");  
		} 	

		catch (Exception e) {
			e.printStackTrace();
		}      
		
	}

	public void addProject(String projectName) {
		// TODO Auto-generated method stub
		
	}

	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		
	}

	public void addGradesForProject(String projectName, HashMap<Student, Integer> grades,
			HashMap<String, Integer> grades2) {
		// TODO Auto-generated method stub
		
	}
	
	public int getOverallGrade(Student student) throws GradeFormulaException{
		//String f;
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("JavaScript");
		try{
			engine.put("AT", student.getAttendance());
			engine.put("AS", student.getAverageAssignmentsGrade());
			engine.put("PR", student.getAverageProjectsGrade());
			
			return (int) Math.round((Double) engine.eval(formula));
		}catch(ScriptException e){
			throw new GradeFormulaException("Invalid formula");
		}
		
	}
	
	public String getFormula() {
		return formula;

	}
	
	public void setFormula(String formula) {
		this.formula = formula;
	}
	
	public String getTeam(Student student){
		XSSFSheet sheet = wb.getSheet("Teams");
		
		for(Row row : sheet){
			if(row.getRowNum() == 0 || row.getCell(0).toString().compareTo("") == 0){
				continue;
			}
			boolean col = false;
			int x = 1;

			while(!col){
				if(row.getCell(x) == null){
					col = true;
				}
				else if(row.getCell(x).toString().compareTo(student.getName()) == 0) {
					 col = true;
					 return row.getCell(0).toString();
				}
				else{
					x++;
				}
			}
		}
		
		return null;

	}
	

}

