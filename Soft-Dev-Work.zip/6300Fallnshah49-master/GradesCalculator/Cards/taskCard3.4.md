# Task Card 3.4

Extend the GradesDB class so that it provides a way to add students.