package edu.gatech.seclass.assignment7;

public class MyClass {
	
	public int buggyMethod1(int x, int y){
		int result;
		result = x + y;
		if(result > 0)
		{
			return x/y;
		}
		if(result < 0)
		{
			return x*y;
		}
		else
		{
			return result;
		}
		
	}
	
	public int buggyMethod2(int x, int y){
		int result;
		result = x + y;
		if(result > 0 || y > 0)
		{
			return x/y;
		}
		if(result < 0)
		{
			return x*y;
		}
		else
		{
		    return 0;
		}
	}
	
}
