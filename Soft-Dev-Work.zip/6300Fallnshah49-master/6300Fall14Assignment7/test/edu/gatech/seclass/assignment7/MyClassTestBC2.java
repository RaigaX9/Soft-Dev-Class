package edu.gatech.seclass.assignment7;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyClassTestBC2 {

	@Test
	public void testBuggyMethod2BC() {
		MyClass mc = new MyClass();
		assertEquals(0, mc.buggyMethod2(3, -3));
	
		
	}
	
	@Test
	public void testBuggyMethod2BC2() {
		MyClass mc = new MyClass();
		assertEquals(7, mc.buggyMethod2(-7, -1));

	}
	
	@Test
	public void testBuggyMethod2BC3() {
		MyClass mc = new MyClass();
		assertEquals(2, mc.buggyMethod2(6, 3));

	}
	
	@Test
	public void testBuggyMethod2BC4() {
		MyClass mc = new MyClass();
		assertEquals(-9, mc.buggyMethod2(9, -1));

	}
	
	@Test
	public void testBuggyMethod2BC5() {
		MyClass mc = new MyClass();
		assertEquals(-9, mc.buggyMethod2(-9, 1));

	}
}
