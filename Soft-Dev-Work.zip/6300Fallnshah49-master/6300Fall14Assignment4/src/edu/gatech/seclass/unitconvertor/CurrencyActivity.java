package edu.gatech.seclass.unitconvertor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CurrencyActivity extends Activity {

	private EditText editDollars;
	private EditText editEuros;
	private Button converttoEuros;
	private Button converttoDollars;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_currency);
		editDollars = (EditText) findViewById(R.id.editDollars);
		editEuros = (EditText) findViewById(R.id.editEuros);
		converttoEuros = (Button) findViewById(R.id.converttoEuros);
		converttoDollars = (Button) findViewById(R.id.converttoDollars);
		
		//Converts US dollars to Euros
		converttoEuros.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				//This will display a message at the bottom if dollars is empty
				if(editDollars.getText().toString().equals("")) 
	            {
	                Toast.makeText(getBaseContext(), "Please enter in a value!", Toast.LENGTH_SHORT).show();

	            }
				else{
					double dollars = Double.valueOf(editDollars.getText().toString());
					double euros = dollars * 0.78;
					editEuros.setText(String.valueOf(euros));
				}
			}
		});
		
		//Converts Euros to US dollars
		converttoDollars.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				//This will display a message at the bottom if euros is empty
				if(editEuros.getText().toString().equals("")) 
	            {
	                Toast.makeText(getBaseContext(), "Please enter in a value!", Toast.LENGTH_SHORT).show();

	            }
				else{
					double euros = Double.valueOf(editEuros.getText().toString());
					double dollars = euros * 1.28;
					editDollars.setText(String.valueOf(dollars));
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.currency, menu);
		return true;
	}
	
    public void toMainAct(View view) 
    {
        Intent intent = new Intent(CurrencyActivity.this, MainActivity.class);
        startActivity(intent);
    }

}
