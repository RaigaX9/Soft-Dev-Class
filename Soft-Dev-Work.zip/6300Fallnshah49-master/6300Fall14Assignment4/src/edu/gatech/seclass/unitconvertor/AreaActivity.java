package edu.gatech.seclass.unitconvertor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AreaActivity extends Activity {
	
	private EditText editsqFeet;
	private EditText editsqMeters;
	private Button convertsqFttosqM;
	private Button convertsqMtosqFt;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_area);
		editsqFeet = (EditText) findViewById(R.id.editsqFeet);
		editsqMeters = (EditText) findViewById(R.id.editsqMeters);
		convertsqFttosqM = (Button) findViewById(R.id.convertsqFttosqM);
		convertsqMtosqFt = (Button) findViewById(R.id.convertsqMtosqFt);
		
		//Converts square feet to square meters
		convertsqFttosqM.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				//This will display a message at the bottom if square feet is empty
				if(editsqFeet.getText().toString().equals("")) 
	            {
	                Toast.makeText(getBaseContext(), "Please enter in a value!", Toast.LENGTH_SHORT).show();

	            }
				else{
					double squareFeet = Double.valueOf(editsqFeet.getText().toString());
					double squareMeters = squareFeet * 0.09290304;
					editsqMeters.setText(String.valueOf(squareMeters));
				}
			}
		});
		
		//Converts square meters to square feet
		convertsqMtosqFt.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				//This will display a message at the bottom if square meters is empty
				if(editsqMeters.getText().toString().equals("")) 
	            {
	                Toast.makeText(getBaseContext(), "Please enter in a value!", Toast.LENGTH_SHORT).show();

	            }
				else{
					double squareMeters = Double.valueOf(editsqMeters.getText().toString());
					double squareFeet = squareMeters * 10.7639;
					editsqFeet.setText(String.valueOf(squareFeet));
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.area, menu);
		return true;
	}
	
    public void toMainAct(View view) 
    {
        Intent intent = new Intent(AreaActivity.this, MainActivity.class);
        startActivity(intent);
    }

}
