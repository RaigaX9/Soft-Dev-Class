package edu.gatech.seclass.unitconvertor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DistanceActivity extends Activity {
	
	private EditText editMiles;
	private EditText editKm;
	private Button convertMtoKm;
	private Button convertKmtoM;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_distance);
		editMiles = (EditText) findViewById(R.id.editMiles);
		editKm = (EditText) findViewById(R.id.editKm);
		convertMtoKm = (Button) findViewById(R.id.convertMtoKm);
		convertKmtoM = (Button) findViewById(R.id.convertKmtoM);

		//Convert Miles to Kilometers
		convertMtoKm.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){	
				//This will display a message at the bottom if miles is empty
				if(editMiles.getText().toString().equals("")) 
	            {
	                Toast.makeText(getBaseContext(), "Please enter in a value!", Toast.LENGTH_SHORT).show();

	            }
				else{
					double miles = Double.valueOf(editMiles.getText().toString());
					double kilometers = miles * 1.609344;
					editKm.setText(String.valueOf(kilometers));
				}
			}
		});
		
		//Convert kilometers to miles
		convertKmtoM.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				//This will display a message at the bottom if kilometers is empty
				if(editKm.getText().toString().equals("")) 
	            {
	                Toast.makeText(getBaseContext(), "Please enter in a value!", Toast.LENGTH_SHORT).show();

	            }
				else{
					double kilometers = Double.valueOf(editKm.getText().toString());
					double miles = kilometers * 0.6214;
					editMiles.setText(String.valueOf(miles));
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.distance, menu);
		return true;
	}
	
    public void toMainAct(View view) 
    {
        Intent intent = new Intent(DistanceActivity.this, MainActivity.class);
        startActivity(intent);
    }


}
