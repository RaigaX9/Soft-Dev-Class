package edu.gatech.seclass.gradescalc;

public class GradeFormulaException extends RuntimeException {

    public GradeFormulaException(String message) {
        super(message);
    }
}
