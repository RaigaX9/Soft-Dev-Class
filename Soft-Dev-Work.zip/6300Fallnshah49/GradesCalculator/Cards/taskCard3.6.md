# Task Card 3.6

Extend the GradesDB class so that it provides a way to add grades to projects.