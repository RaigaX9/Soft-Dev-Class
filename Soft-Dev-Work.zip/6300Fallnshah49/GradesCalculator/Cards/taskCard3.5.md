# Task Card 3.5

Extend the GradesDB class so that it provides a way to add a project.