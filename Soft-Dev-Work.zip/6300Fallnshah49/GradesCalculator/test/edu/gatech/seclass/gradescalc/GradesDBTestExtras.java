package edu.gatech.seclass.gradescalc;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GradesDBTestExtras {

    GradesDB db = null;
    static final String GRADES_DB_GOLDEN = "DB" + File.separator
            + "GradesDatabase6300-goldenversion.xlsx";
    static final String GRADES_DB = "DB" + File.separator
            + "GradesDatabase6300.xlsx";

    @Before
    public void setUp() throws Exception {
        FileSystem fs = FileSystems.getDefault();
        Path dbfilegolden = fs.getPath(GRADES_DB_GOLDEN);
        Path dbfile = fs.getPath(GRADES_DB);
        Files.copy(dbfilegolden, dbfile, REPLACE_EXISTING);
       // db = new GradesDB(GRADES_DB);
    }

    @After
    public void tearDown() throws Exception {
        db = null;
    }

    
    @Test
    public void testAddStudent(){
    	Student student = new Student("Nishad Shah", "9023987", db);
    	db.addStudent(student);
    	//assertEquals(student, db.getStudentByName("Nishad Shah"));
    	
    	Student student2 = new Student("Gon Frecess", "9032135", db);
    	db.addStudent(student2);
    	//assertEquals(student2, db.getStudentByID("9032135"));
    }
    
    @Test
    public void testAddProject(){
        db.addProject("PROJECT: SMASH");
       // db = new GradesDB(GRADES_DB);
        //assertEquals(4, db.getNumProjects());
        db.addProject("PROJECT: FALCON PUNCH");
       // db = new GradesDB(GRADES_DB);
        //assertEquals(5, db.getNumProjects());
    }
    
    @Test
    public void testAddGradesForProject(){
        String projectName = "PROJECT: OMEGA RUBY";
        Student student = new Student("Genista Parrish", "901234509", db);
        HashMap<Student, Integer> grades = new HashMap<Student, Integer>();
        HashMap<String, Integer> grades2 = new HashMap<String, Integer>();
        db.addProject(projectName);
        //db = new GradesDB(GRADES_DB);
        db.addIndividualContributions(projectName, grades);
        grades.put(student, 110);
        grades2.put("Team 2", 98);

        db.addGradesForProject(projectName, grades, grades2);
        //db = new GradesDB(GRADES_DB);
        //assertEquals(90, db.getAverageProjectsGrade(student), 1);

    }
}