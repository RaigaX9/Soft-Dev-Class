package edu.gatech.seclass.assignment3;


import static org.junit.Assert.assertEquals;

import org.junit.*;

public class MyStringTest {

	@Test
	public void testGetVowels() throws Exception {
		MyString myString = new MyString();
		MyString myString2 = new MyString();
	    
		//This will test if a string does not contain any vowel
		myString.setString("qwrt");
	    assertEquals("", myString.getVowels());
	    
	    //This will test if a string contains vowels
	    myString2.setString("aEUfdsvserOiIcd");
	    assertEquals("aEUeOiI", myString2.getVowels());
	}
	
	@Test
	public void testGetSubstring() throws Exception {
		MyString myString = new MyString();
		MyString myString2 = new MyString();
		
		//This will test the substring  going from the specific start point to the end point
		myString.setString("Nebuious Clock");
	    assertEquals("Clock", myString.getSubstring(10, 15));
	    
	    //This will test the substring with the same starting and end points
	    myString2.setString("Nebuious Clock");
	    assertEquals("", myString2.getSubstring(2, 2));
	}
	
	@Test
	public void testIndexOf() throws Exception {
		MyString myString = new MyString();
		MyString myString2 = new MyString();
	    
	    //This will test if there is char that is not contained in a string
		myString.setString("Blueberry Pie");
	    assertEquals(0, myString.indexOf('x'));
	    
	    //This will test if there is a char contained in a string at the first occurrences
	    myString2.setString("Panang Curry");
	    assertEquals(3, myString2.indexOf('n'));
	}
	
	@Test
	public void testRemoveChar() throws Exception {
		MyString myString = new MyString();
		MyString myString2 = new MyString();
		
		myString.setString("Taka");
	    
	    //This test will remove a char from a string
		myString.removeChar('a');
	    assertEquals("Tk", myString.getString());
	    
	    //This test will not remove a char if it is not contained within the string
	    myString2.setString("Zero");
	    myString2.removeChar('p');
	    assertEquals("Zero", myString2.getString());
	    
	}
	
	@Test
	public void testInvert() throws Exception {
		MyString myString = new MyString();
	    MyString myString2 = new MyString();
		
	    //This will test the inverted string
	    myString.setString("basuketto");
	    myString.invert();
	    assertEquals("ottekusab", myString.getString());
	    
	    //This will test if there is no string to invert
	    myString2.setString("");
	    myString2.invert();
	    assertEquals("", myString2.getString());
	}
	
}
