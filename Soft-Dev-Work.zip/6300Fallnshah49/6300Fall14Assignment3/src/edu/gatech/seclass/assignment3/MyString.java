package edu.gatech.seclass.assignment3;

public class MyString implements MyStringInterface {

	private String str;
    
    public MyString(String str)
    {
		this.str = str;
	}
	
	public MyString()
	{
		
	}
	
	public void setString(String str)
	{
		this.str = str;
	}

	public String getString()
	{
		return this.str;
	}

	public String getVowels() 
	{
		String str2 = ""; 
		String vowels = "aeiouAEIOU"; 
		for(int i = 0; i < str.length(); i++)
		{
			if(vowels.indexOf(str.charAt(i)) != -1)
			{
				str2 = str2 + str.charAt(i); 
			}
		}

		return str2; 
	}

	public String getSubstring(int start, int end) 
	{
		str = this.str.substring(start-1, end-1);
		return str;
	}

	public int indexOf(char c) 
	{
        int index;
        index = str.indexOf(c);
        index = index + 1;
        return index; 
	}
	

	public void removeChar(char c) 
	{
		StringBuilder buildStr = new StringBuilder();
		 char[] removeStr = str.toCharArray();

	        for(int i = 0; i < removeStr.length; i++)
	        {
	            if(removeStr[i] == c)
	            {
	            	
	            } 
	            else 
	            {
	            	buildStr.append(removeStr[i]);
	            }
	            str = buildStr.toString();
	        }		 
	}
	public void invert() 
	{
	    if(str.length() > 0)
	    {
	        String x = str.substring(0,1);
	        String reverse = str.substring(1);

	        MyString myString = new MyString(reverse);
	        myString.invert();

	        str = myString.str + x;
	    }
		
	}
}
