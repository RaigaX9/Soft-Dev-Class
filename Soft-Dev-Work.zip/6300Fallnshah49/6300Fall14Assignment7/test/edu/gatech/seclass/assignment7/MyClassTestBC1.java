package edu.gatech.seclass.assignment7;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyClassTestBC1 {
	
	@Test
	public void testBuggyMethod1BC() {
		MyClass mc = new MyClass();
		assertEquals(0, mc.buggyMethod1(-3, 3));

	}
	
	@Test
	public void testBuggyMethod1BC2() {
		MyClass mc = new MyClass();
		assertEquals(1, mc.buggyMethod1(3, 3));

	}
	@Test
	public void testBuggyMethod1BC3() {
		MyClass mc = new MyClass();
		assertEquals(-6, mc.buggyMethod1(-3, 2));

	}
	@Test
	public void testBuggyMethod1BC4() {
		MyClass mc = new MyClass();
		int test = mc.buggyMethod1(5, 0);
	}


}
