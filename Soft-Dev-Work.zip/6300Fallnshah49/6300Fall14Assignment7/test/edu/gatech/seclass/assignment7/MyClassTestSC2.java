package edu.gatech.seclass.assignment7;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyClassTestSC2 {

	@Test
	public void testBuggyMethod2SC() {
		MyClass mc = new MyClass();
		assertEquals(0, mc.buggyMethod2(3, -3));
	
		
	}
	
	@Test
	public void testBuggyMethod2SC2() {
		MyClass mc = new MyClass();
		assertEquals(7, mc.buggyMethod2(-7, -1));

	}
	
	@Test
	public void testBuggyMethod2SC3() {
		MyClass mc = new MyClass();
		assertEquals(4, mc.buggyMethod2(8, 2));
	}
	
	@Test
	public void testBuggyMethod2SC4() {
		MyClass mc = new MyClass();
		assertEquals(-9, mc.buggyMethod2(9, -1));

	}
	
	
	@Test
	public void testBuggyMethod2SC5() {
		MyClass mc = new MyClass(); 
		int test = mc.buggyMethod2(5, 0);

	}


}
