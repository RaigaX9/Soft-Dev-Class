package edu.gatech.seclass.assignment7;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyClassTestSC1 {

	@Test
	public void testBuggyMethod1SC() {
		MyClass mc = new MyClass();

		assertEquals(0, mc.buggyMethod1(-3, 3));
		assertEquals(1, mc.buggyMethod1(3, 3));
		assertEquals(-6, mc.buggyMethod1(-3, 2));

	}

}
