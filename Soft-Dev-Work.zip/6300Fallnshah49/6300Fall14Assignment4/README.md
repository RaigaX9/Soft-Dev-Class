## Instructions ##

1. When you start the app, there will be  three buttons available on the main screen which are  'Distance Converter', 'Area Converter', and 'Currency Converter'.

2. Here are where each of the buttons will take you and what their functions are:
	
	* Distance Converter - Converts miles to kilometers and vice versa
	* Area Converter - Converts square feet to square meters and vice versa
	* Currency Converter - Converts US Dollars to Euros and vice versa

3. Let's say we click on 'Distance Converter'. We will go to another screen and in there there will be two edit boxes from top to bottom which are miles
and kilometers. So if you want to convert miles to kilometers, type in your in the text field under the word 'Miles' and once you did that, click on the
button 'Convert to Kilometers' and it will show you the conversion from miles to kilometers under the kilometers text field. Or if you want to do it from kilometers
to miles, type in your input in the kilometers text field and once that's done, click on the button 'Convert to Miles' and it will show the conversion from
kilometers to miles in the miles textfield.

This will be the same process for both Area Converter and Currency Converter, but with different conversions.

4. To go back to the main screen, click either on the "Go Back" button or press the devices' back button.

Conversion Info:
1 Mile = 1.609344 Kilometers
1 Kilometer = 0.6214 Miles
1 Square Feet = 0.092903 Square Meters
1 Square Meter = 10.7639 Square Feet
1 US Dollar = 0.78 Euros
1 Euro = 1.28